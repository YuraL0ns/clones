@extends('theme.main')

@section('page-name')
    Создать проект
    <hr>  
@endsection

@section('content')

{!! Form::open(['action' => 'SkladController@store', 'method' => 'POST']) !!}
  <div class="form-group">
	{{ Form::label('name' ,'Имя',['class'=>'form-label']) }}
	{{ Form::text('name', null,['class'=>'form-control', 'placeholder' => 'Название наименования']) }}
  </div>
  <div class="form-inline">
  	<div class="form-group col-md-6">
		{{ Form::label('in' ,'На складе',['class'=>'form-label']) }}
		{{ Form::number('in', null,['class'=>'form-control']) }}
	  </div>
	  <div class="form-group col-md-6">
		{{ Form::label('out' ,'Зарезервираванно',['class'=>'form-label']) }}
		{{ Form::number('out', null,['class'=>'form-control']) }}
	  </div>
  </div>
  {{ Form::submit('Добавить наименование',['class'=>'btn btn-success btn-block btn-lg col-md-12','style' => 'margin-top: 25px;']) }}
   
{!! Form::close() !!}

@endsection