@extends('theme.main')
@section('page-name')
Склад
@endsection
@section('content')
    <div class="container-fluid">
    	<a href="/sklader/create" class="btn btn-success btn-block">Добавить наименование</a>
		<table class="table">
			<thead>
				<th>Название</th>
				<th>Кол-во на складе</th>
				<th>Кол-во зарезервираванно</th>
			</thead>
			<tbody>
				
		@foreach($sklad as $sklad)<tr>
				<td>{{ $sklad->name }}</td>
				<td>{{ $sklad->in }}</td>
				<td>{{ $sklad->out }}</td>
				</tr>@endforeach
		</tbody>
		</table>

   </div>
@endsection