@extends('layouts.app')

@section('sidebar')
    @include('admin.layouts.sidebar')
@endsection

@section('header')
    @include('admin.layouts.header')
@endsection

@section('content')
    <div class="container-fluid">
{!! Form::open(['action' => 'Admin\SkladController@store', 'method' => 'POST']) !!}
  <div class="form-group">
	{{ Form::label('name' ,'Имя',['class'=>'form-label']) }}
	{{ Form::text('name', null,['class'=>'form-control', 'placeholder' => 'Название наименования']) }}
  </div>
  <div class="form-inline">
  	<div class="form-group col-md-6">
		{{ Form::label('in' ,'На складе',['class'=>'form-label']) }}
		{{ Form::number('in', null,['class'=>'form-control']) }}
	  </div>
	  <div class="form-group col-md-6">
		{{ Form::label('out' ,'Зарезервираванно',['class'=>'form-label']) }}
		{{ Form::number('out', null,['class'=>'form-control']) }}
	  </div>
  </div>
  {{ Form::submit('Добавить наименование',['class'=>'btn btn-success btn-block btn-lg col-md-12','style' => 'margin-top: 25px;']) }}
   
{!! Form::close() !!}
   </div>
@endsection

@push('styles')
    <link href="{{ asset('css/admin/sb-admin-2.css') }}" rel="stylesheet">
@endpush

@push('scripts')
    <script src="{{ asset('js/admin/sb-admin-2.js') }}"></script>
@endpush