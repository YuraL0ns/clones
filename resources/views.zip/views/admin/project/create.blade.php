@extends('layouts.app')

@section('sidebar')
    @include('admin.layouts.sidebar')
@endsection

@section('header')
    @include('admin.layouts.header')
@endsection

@section('content')
    <div class="container-fluid">
        <section class="content">
            <form action="{{ route('projects.store') }}" method="post">
                @csrf
                <div class="row">
                    <div class="col-md-6">
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Основное</h3>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="inputName">*Название проекта</label>
                                    <input type="text" id="inputName" class="form-control" name="name">
                                </div>
                                <div class="form-group">
                                    <label for="inputQuest">Задача проекта(общая)</label>
                                    <textarea id="inputQuest" class="form-control" rows="4" name="quest"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="inputClientCompany">Заказчик(опционально)</label>
                                    <input type="text" id="inputClientCompany" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="inputProjectLeader">Кто глава проекта</label>
                                    <input type="text" id="inputProjectLeader" class="form-control">
                                </div>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <div class="col-md-6">
                        <div class="card card-secondary">
                            <div class="card-header">
                                <h3 class="card-title">Даты работы проекта</h3>
                            </div>
                            <div class="card-body">                                   
                                <div class="form-group">
                                    <label for="inputEstimatedDuration">Начало и конец проекта</label>
                                    <div class="form-group row d-flex justify-content-between">
                                        с <input type="date" id="inputName" class="form-control" name="start"> 
                                        до
                                        <input type="date" id="inputName" class="form-control" name="end">
                                    </div>
                                    <label for="inputEstimatedDuration">Время для проектирования</label>
                                    <div class="form-group row d-flex justify-content-between">
                                        с <input type="date" id="inputName" class="form-control" name="ps"> 
                                        до
                                        <input type="date" id="inputName" class="form-control" name="pe">
                                    </div>
                                    <label for="inputEstimatedDuration">Время для снабжения</label>
                                    <div class="form-group row d-flex justify-content-between">
                                        с <input type="date" id="inputName" class="form-control" name="ss">
                                        до
                                        <input type="date" id="inputName" class="form-control" name="se">
                                    </div>
                                    <label for="inputEstimatedDuration">Время на производство</label>
                                    <div class="form-group row d-flex justify-content-between">
                                        с <input type="date" id="inputName" class="form-control" name="prs">
                                        до
                                        <input type="date" id="inputName" class="form-control" name="pre">
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card card-secondary">
                            <div class="card-header">
                                <h3 class="card-title">Задача для пользователей</h3>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="project-create-users-select">Пользователи</label>
                                    <select id="project-create-users-select" class="js-example-basic-multiple w-100" name="users[]" multiple="multiple">
                                        @foreach($users as $user)
                                            <option value="{{ $user->id }}">{{ $user->full_name . ' - ' . $user->email }}</option>
                                        @endforeach
                                    </select>

                                    <div class="card border-0 mt-3 mb-3 tasks-section">
                                        <div class="card-title">Задачи пользователя</div>
                                        <div class="card-body">
                                            <div class="row border-warning border p-4 tasks">

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('projects.index') }}" class="btn btn-secondary">Отмена</a>
                        <input type="submit" value="Создать проект" class="btn btn-success float-right">
                    </div>
                </div>
            </form>
        </section>
    </div>
@endsection

@push('styles')
    <link href="{{ asset('css/admin/sb-admin-2.css') }}" rel="stylesheet">
    <link href="{{ asset('css/select2.css') }}" rel="stylesheet">
@endpush

@push('scripts')
    <script src="{{ asset('js/admin/sb-admin-2.js') }}"></script>
    <script src="{{ asset('js/select2.js') }}"></script>
    <script>
        $(document).ready(function() {
            let selectBox = $('.js-example-basic-multiple'),
                tasksSection = $('.tasks-section .tasks');

            selectBox.select2();


            selectBox.on('select2:select', function (e) {
                let data = e.params.data,
                    html = '';

                    html = '<div class="card col-3 task" data-id="'+data.id+'">\n' +
                        '   <div class="card-body">\n' +
                        '       <h5 class="card-title">'+data.text.split(' - ')[0]+'</h5>\n' +
                        '       <h6 class="card-subtitle mb-2 text-muted">'+data.text.split(' - ')[1]+'</h6>\n' +
                        '       <div class="form-group">\n' +
                        '         <label for="task-description">Задача</label>\n' +
                        '         <textarea id="task-description" class="card-text form-control" name="descriptions['+data.id+']"></textarea>\n' +
                        '       </div>\n' +
                        '       <div class="form-group">\n' +
                        '         <label for="task-start-date">Start Date</label>\n' +
                        '         <input id="task-start-date" type="date" class="form-control" name="start_dates['+data.id+']">\n' +
                        '       </div>\n' +
                        '       <div class="form-group">\n' +
                        '          <label for="task-end-date">End Date</label>\n' +
                        '          <input id="task-end-date" type="date" class="form-control" name="end_dates['+data.id+']">\n' +
                        '       </div>\n' +
                        '    </div>\n' +
                        '</div>';

                    tasksSection.append(html);
            });

            selectBox.on('select2:unselect', function (e) {
                let data = e.params.data,
                    tasks = document.querySelectorAll('.tasks-section .tasks .task');

                tasks.forEach(function (item, index) {
                    let id = $(item).attr('data-id');

                    if (parseInt(data.id) === parseInt(id)) {
                        $(item).remove()
                    }
                })
            });

            selectBox.on('select2:clear', function (e) {
                tasksSection.empty()
            })
        });
    </script>
@endpush