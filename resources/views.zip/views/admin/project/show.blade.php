@extends('layouts.app')

@section('sidebar')
    @include('admin.layouts.sidebar')
@endsection

@section('header')
    @include('admin.layouts.header')
@endsection

@section('content')
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Детали проекта "{{ $project->name }}"</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-8 order-2 order-md-1">
                        <div class="row">
                            <div class="col-12 col-sm-4">
                                <div class="info-box bg-light">
                                    <div class="info-box-content">
                                        <div class="alert bg-gradient-info" role="alert">
                                          <h4 class="alert-heading text-gray-100">Проектирование</h4>
                                          <p class="text-gray-100">{{ \Carbon\Carbon::parse($project->ps)->format('d.m.Y')}}  до {{ \Carbon\Carbon::parse($project->pe)->format('d.m.Y')}}</p>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-4">
                                <div class="info-box bg-light">
                                    <div class="info-box-content">
                                         <div class="alert bg-gradient-danger" role="alert">
                                          <h4 class="alert-heading text-gray-100">Снабжение</h4>
                                          <p class="text-gray-100">{{ \Carbon\Carbon::parse($project->ss)->format('d.m.Y')}}  до {{ \Carbon\Carbon::parse($project->se)->format('d.m.Y')}}</p>
                                        </div>
                                            
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-4">
                                <div class="info-box bg-light">
                                    <div class="info-box-content">
                                        <div class="alert bg-gradient-success" role="alert">
                                          <h4 class="alert-heading text-gray-100">Производство</h4>
                                          <p class="text-gray-100">{{ \Carbon\Carbon::parse($project->prs)->format('d.m.Y')}}  до {{ \Carbon\Carbon::parse($project->pre)->format('d.m.Y')}}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <h4>Задача для команд</h4>

                        <div class="card">
                            <div class="card-header d-flex p-0">
                                <ul class="nav nav-pills  p-2">
                                    {{--@role('construct|suAdmin')--}}
                                    {{--<li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">Конструктора</a></li>--}}
                                    {{--@endrole--}}
                                    {{--@role('suAdmin')--}}
                                    {{--<li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab">Снабжение</a></li>--}}
                                    {{--@endrole--}}
                                    {{--@role('Ingener|suAdmin')--}}
                                    {{--<li class="nav-item"><a class="nav-link" href="#tab_3" data-toggle="tab">Проектирование</a></li>--}}
                                    {{--@endrole--}}
                                    @foreach($project->tasks as $key => $task)
                                        <li class="nav-item">
                                            <a class="nav-link {{ $key === 0 ? 'active' : '' }}" href="#tab_{{ $key }}" data-toggle="tab">{{ $task->owner->full_name }}</a>
                                        </li>
                                    @endforeach
                                </ul>
                            </div><!-- /.card-header -->
                            <div class="card-body">
                                <div class="tab-content">
                                    @foreach($project->tasks as $key => $task)
                                        <div class="tab-pane {{ $key === 0 ? 'active' : '' }}" id="tab_{{ $key }}">
                                            {{ $task->description }}
                                        </div>
                                @endforeach
                                <!-- /.tab-pane -->
                                </div>
                                <!-- /.tab-content -->
                            </div><!-- /.card-body -->
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-12">
                                <h4>Комментарии</h4>
                                <hr>
                                <div class="post">
                                    @foreach( $project->comments as $comment )
                                        <p>
                                            {{ $comment->body }}
                                        </p>
                                    @endforeach
                                </div>
                                <div class="card-block">
                                    <form method="POST" action="/project/{{ $project->id }}/comments">
                                        {{ csrf_field() }}
                                        <div class="form-group">
                                            <input name="body" class="form-control" id="textarea" placeholder="Напишите что нибудь !">
                                        </div>
                                        <button type="submit" class="btn btn-success">Ответить</button>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-12 col-lg-4 order-1 order-md-2">
                        <h3 class="text-primary"><i class="fas fa-tasks"></i> {{ $project->name }}</h3>
                        <p class="text-muted">{{ $project->quest }}</p>
                        <br>
                        <div class="text-muted">
                            <p class="text-sm">Дата начала проекта и его конец
                                <b class="d-block">с {{ \Carbon\Carbon::parse($project->start)->format('d.m.Y')}} до {{ \Carbon\Carbon::parse($project->end)->format('d.m.Y')}}</b>
                            </p>
                            
                        </div>

                        <h5 class="mt-5 text-muted">Файлы проекта</h5>
                        <ul class="list-unstyled">
                            <li>
                                <a href="" class="btn-link text-secondary"><i class="far fa-fw fa-file-word"></i> Проверка</a>
                            </li>
                            
                        </ul>
                        <div class="text-center mt-5 mb-3">
                            <button type="file" class="btn btn-sm btn-primary">Добавить файл</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
        </div>
    </div>
@endsection

@push('styles')
    <link href="{{ asset('css/admin/sb-admin-2.css') }}" rel="stylesheet">
@endpush

@push('scripts')
    <script src="{{ asset('js/admin/sb-admin-2.js') }}"></script>
@endpush