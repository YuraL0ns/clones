@extends('theme.main')

@section('page-name')
    Панель управления | Главная страница
@endsection

@section('content')

	@can('show project')
	<a href="/project" type="button" class="btn btn-info btn-lg btn-block">Проекты</a>
	@endcan
	@role('Администратор|Директор|Снабжение|Склад|Инжинер|Конструктор\АСУ')
	<a href="/sklader" type="button" class="btn btn-warning btn-lg btn-block">Склад</a>
	@endrole
	{{-- button type="button" class="btn btn-primary btn-lg btn-">Бухгалтерия</button>
	<button type="button" class="btn btn-primary btn-lg btn-">Снабжение</button>
	<button type="button" class="btn btn-primary btn-lg btn-">Директора</button>--}}
	@role('Администратор|Директор')<button type="button" class="btn btn-danger btn-lg btn-block">Администрация</button>@endrole


@endsection