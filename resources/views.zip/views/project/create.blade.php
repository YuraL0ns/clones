@extends('theme.main')

@section('page-name')
    Создать проект
    <hr>  
@endsection

@section('content')

{!! Form::open() !!}

{!! Form::close() !!}

@endsection