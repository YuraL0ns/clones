@extends('theme.main')

@section('page-name')
Проекты
@endsection

@section('content')

<table class="table table-striped projects">
	<thead>
		<tr>
			<th style="width: 55%">
				Название проекта
			</th>
			<th>
				Статус
			</th>
			<th style="width: 15%">
				Дата начала проекта
			</th>
			<th style="width: 20%">
				Действия
			</th>
		</tr>
	</thead>
	<tbody>
		@foreach($projects as $project)
			<tr>
				<td>
					{{ $project->name }}
				</td>
				<td>
					{{--@foreach($project->status as $status)--}}
						{{--<span class="badge">{{ $status->status_id }}</span>--}}
					{{--@endforeach--}}
				</td>
				<td>
					{{$project->start}}
				</td>
				<td class="row">
					<a href="{{ route('project.show', ['project' => $project->id]) }}" class="btn btn-info col"><i class="fas fa-eye"></i> Просмотр проекта</a>
				</td>
			</tr>
	@endforeach
</tbody>
</table>
@endsection