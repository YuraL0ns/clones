@extends('theme.main')

@section('page-name')
  {{ $project->name }}
@endsection

@section('content')

<div class="card">
<div class="card-header">
  <h3 class="card-title">Детали проекта</h3>
</div>
<div class="card-body">
  <div class="row">
    <div class="col-12 col-md-12 col-lg-8 order-2 order-md-1">
      <div class="row">
        <div class="col-12 col-sm-4">
          <div class="info-box bg-light">
            <div class="info-box-content">
              <span class="info-box-text text-center text-muted">Дата проектирования</span>
              <span class="info-box-number text-center text-muted mb-0">{{ $project->ps }} до {{ $project->pe }}</span>
            </div>
          </div>
        </div>
        <div class="col-12 col-sm-4">
          <div class="info-box bg-light">
            <div class="info-box-content">
              <span class="info-box-text text-center text-muted">Снабжение</span>
              <span class="info-box-number text-center text-muted mb-0">{{ $project->ss }} до {{ $project->se }}</span>
            </div>
          </div>
        </div>
        <div class="col-12 col-sm-4">
          <div class="info-box bg-light">
            <div class="info-box-content">
              <span class="info-box-text text-center text-muted">Производство</span>
              <span class="info-box-number text-center text-muted mb-0">{{ $project->prs }} до {{ $project->pre }}</span>
            </div>
          </div>
        </div>
      </div>
      <h4>Задача для команд</h4>
      @hasanyrole('Администратор|Директор|Программист|Инжинер|Конструктор\АСУ')
      <div class="card">
        <div class="card-header d-flex p-0">
          <ul class="nav nav-pills  p-2">
            {{--@role('construct|suAdmin')--}}
            {{--<li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">Конструктора</a></li>--}}
            {{--@endrole--}}
            {{--@role('suAdmin')--}}
            {{--<li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab">Снабжение</a></li>--}}
            {{--@endrole--}}
            {{--@role('Ingener|suAdmin')--}}
            {{--<li class="nav-item"><a class="nav-link" href="#tab_3" data-toggle="tab">Проектирование</a></li>--}}
            {{--@endrole--}}
            @foreach($project->tasks as $key => $task)
              <li class="nav-item">
                <a class="nav-link {{ $key === 0 ? 'active' : '' }}" href="#tab_{{ $key }}" data-toggle="tab">{{ $task->owner->full_name }}</a>
              </li>
            @endforeach
          </ul>
        </div><!-- /.card-header -->
        <div class="card-body">
          <div class="tab-content">
            @foreach($project->tasks as $key => $task)
              <div class="tab-pane {{ $key === 0 ? 'active' : '' }}" id="tab_{{ $key }}">
                {{ $task->description }}
              </div>
            @endforeach
            <!-- /.tab-pane -->
          </div>
          <!-- /.tab-content -->
        </div><!-- /.card-body -->
      </div>
      @endhasanyrole
<hr>
<div class="row">
<div class="col-12">
<h4>Комментарии</h4>
<hr>
<div class="post">   
@foreach( $project->comments as $comment )          
<p>
{{ $comment->body }}
</p>  
@endforeach 
</div>
<div class="card-block">
  <form method="POST" action="/project/{{ $project->id }}/comments">
  {{ csrf_field() }}
    <div class="form-group">
       <input name="body" class="form-control" id="textarea" placeholder="Напишите что нибудь !">
      </div>
    <button type="submit" class="btn btn-success">Ответить</button>
  </form>
</div>

          </div>
        </div>
      </div>
      <div class="col-12 col-md-12 col-lg-4 order-1 order-md-2">
        <h3 class="text-primary"><i class="fas fa-tasks"></i> {{ $project->name }}</h3>
        <p class="text-muted">{{ $project->quest }}</p>
        <br>
        <div class="text-muted">
          <p class="text-sm">Дата начала проекта и его конец
            <b class="d-block">с {{ $project->start }} до {{ $project->end }}</b>
          </p>
          <p class="text-sm">Кто заказал
            <b class="d-block">Тут будет контрагент</b>
          </p>
          <p class="text-sm">Главный проекта
            <b class="d-block">Tут кто отвечает головой за проект</b>
          </p>
        </div>

        <h5 class="mt-5 text-muted">Файлы проекта</h5>
        <ul class="list-unstyled">
          <li>
            <a href="" class="btn-link text-secondary"><i class="far fa-fw fa-file-word"></i> Functional-requirements.docx</a>
          </li>
          <li>
            <a href="" class="btn-link text-secondary"><i class="far fa-fw fa-file-pdf"></i> UAT.pdf</a>
          </li>
          <li>
            <a href="" class="btn-link text-secondary"><i class="far fa-fw fa-envelope"></i> Email-from-flatbal.mln</a>
          </li>
          <li>
            <a href="" class="btn-link text-secondary"><i class="far fa-fw fa-image "></i> Logo.png</a>
          </li>
          <li>
            <a href="" class="btn-link text-secondary"><i class="far fa-fw fa-file-word"></i> Contract-10_12_2014.docx</a>
          </li>
        </ul>
        <div class="text-center mt-5 mb-3">
          <a href="#" class="btn btn-sm btn-primary">Добавить файл</a>
        </div>
      </div>
    </div>
  </div>
  <!-- /.card-body -->
</div>
@endsection